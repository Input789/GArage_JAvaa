public class Automobile  extends Veicolo{
    //ATtributi
    int cavalli;
    public Automobile(String marca, int prezzo, String modello, int cavalli) {
        super(marca, prezzo, modello);
        this.cavalli = cavalli;
    }



    //MEtodi
    public String toString(){
        return("Sono un veicolo di marca " + marca + " di euro " + prezzo + " di modello " + modello + " e di cavalli " + cavalli);
    }
}
