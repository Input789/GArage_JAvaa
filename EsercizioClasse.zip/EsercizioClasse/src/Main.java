import java.util.ArrayList; // import the ArrayList class
public class Main{
    public static void main(String[]args){
        System.out.println("Hello world");

        //DIchiarazioni da altri file
        ArrayList<Veicolo> garage = new ArrayList<Veicolo>(100); //OGgetto garage
        Veicolo veicolo1 = new Veicolo("Mercedes", 1, "Benz"); //OGgetto veicolo
        //ArrayList<String> garage_file = new ArrayList<String>(100);
        Motocicletta moto1 = new Motocicletta("Ducati", 1, "Modellosa", 100);
        Automobile auto1 = new Automobile("Mercedes", 1, "Modelloso", 100);
        garage.add(veicolo1); //PRima mette veicolo1 in Cont, poi incrementa Cont
        garage.add(moto1); //IL file capisce di dover chiamare il ToString() delle moto
        garage.add(auto1);

        for (Veicolo veicolo : garage){
            System.out.println(veicolo);
        }

        //RIchiamo metodi
        //garage.riempiGarage(garage_file);
        //garage.stampaGarage(garage_file);
        //System.out.println(garage.toString());
        //System.out.println(moto1);

    }
}