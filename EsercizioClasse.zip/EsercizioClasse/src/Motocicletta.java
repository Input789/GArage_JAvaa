public class Motocicletta extends Veicolo {  //UNa motocicletta è un veicolo, è una sottoclasse quindi estendo la superclasse

    //ATtributi Motocicletta
    int cilindrata;
    public Motocicletta(String marca, int prezzo, String modello, int cilindrata) {
        super(marca, prezzo, modello); //LI prendo da super, è la parola da usare
        this.cilindrata = cilindrata;
    }


    //MEtodi

    @Override //RIdefinisco il funzionamento di un metodo esistente
    public String toString(){
        return("Sono un veicolo di marca " + marca + " di euro " + prezzo + " di modello " + modello + " e di cilindrata " + cilindrata);
    }
}
