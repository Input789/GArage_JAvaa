import java.io.File; //CLasse per i file
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList; // import the ArrayList class

public class Veicolo {

    //ATtributi
    File file = new File("data/garage.csv"); //CReo un oggetto che prende i valori dal file
    int DIM = 100;
    int i = 0;
    String marca, modello;
    int prezzo;

    public Veicolo(String marca, int prezzo, String modello){
        this.marca = marca;
        this.prezzo = prezzo;
        this.modello = modello;
    }

    public void Entra(){

    }
    public void Esci(){

    }

    //MEtodi

    public void riempiGarage(ArrayList <String> garage){
        try {
            Scanner scan = new Scanner(file);
            while (scan.hasNextLine()) {
                garage.add(scan.nextLine());
            }
            scan.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

    }

    public void stampaGarage(ArrayList <String> garage){
        for (int i = 0; i<DIM; i++){
            System.out.println(garage.get(i));
        }
    }
    public String toString(){
        return("Sono un veicolo di marca " + marca + " di euro " + prezzo + " e di modello " + modello);
    }
}
